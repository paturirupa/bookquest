const express = require("express");
const cors = require("cors");
const app = express();
const port = 5000;
const userRoute = require("./routes/userRoutes");
const { default: mongoose } = require("mongoose");

app.use(express.json());
app.use(cors());

mongoose
  .connect("mongodb://localhost:27017/bookquest")
  .then((response) => console.log("connected to database"));

app.use("/api/users", userRoute);

app.listen(port, () => {
  console.log(`App listening on port ${port}`);
});
